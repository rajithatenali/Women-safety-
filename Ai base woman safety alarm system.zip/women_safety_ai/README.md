# AI-Based Women's Safety Alarm System (Educational Prototype)

> This application is an educational AI prototype intended to demonstrate safety-assistance concepts. AI predictions may be inaccurate and should not be treated as confirmation of an emergency. In a real emergency, contact appropriate local emergency services.

## Setup
```bash
python -m venv .venv
.venv\Scripts\activate          # Windows   (macOS/Linux: source .venv/bin/activate)
pip install -r requirements.txt
python train_models.py          # optional: app.py does this automatically on first run
streamlit run app.py
```

## Structure
- `app.py` – Streamlit UI (7 pages)
- `train_models.py` – makes sample CSVs + trains models (saved with Joblib in `models/`)
- `utils/voice_detection.py`, `motion_detection.py`, `risk_prediction.py`, `alerts.py`, `vision.py`
- `data/` – SAMPLE/DEMO datasets (synthetic, not real crime data)

## Safety design
No real calls/SMS/email, no facial recognition, audio never saved, alerts only change Streamlit session state.

## Future improvements
Real MFCC features (librosa) and a labelled speech dataset; wearable sensor datasets (e.g. SisFall); verified open crime data; a mobile app with consented SMS/GPS sharing; offline keyword spotting; user-configurable thresholds; automated tests.
