"""AI-Based Women's Safety Alarm System - educational Streamlit prototype.
Run with:  streamlit run app.py
"""
import os

import pandas as pd
import plotly.express as px
import streamlit as st

from utils import alerts, motion_detection as motion, risk_prediction as risk, voice_detection as voice

st.set_page_config(page_title="Women's Safety Alarm (Demo)", page_icon="🛡️", layout="wide")
alerts.init_state()

# Train models automatically the first time (creates sample data + models)
if not (os.path.exists(voice.MODEL_PATH) and os.path.exists(risk.MODEL_PATH)):
    import train_models
    with st.spinner("First run: creating sample data and training models..."):
        train_models.main()

# ---------------- Sidebar ----------------
PAGES = ["🏠 Home Dashboard", "🎤 Distress Voice Detection", "🏃 Fall / Abnormal Motion",
         "📍 Crime Risk Prediction", "🚨 Emergency Alert", "📷 Person Counter (Optional)", "ℹ️ About Project"]
st.sidebar.title("🛡️ Safety Alarm Demo")
page = st.sidebar.radio("Navigate", PAGES)
st.sidebar.markdown("---")
status = st.session_state.alert_status
st.sidebar.markdown({"INACTIVE": "🟢 Alert: inactive", "PENDING": "🟡 Alert: awaiting confirmation",
                     "TRIGGERED": "🔴 Alert: TRIGGERED (simulated)"}[status])
st.sidebar.caption(alerts.DISCLAIMER)


def pending_or_done(where):
    """Shared block: show confirm panel if something is pending, or the triggered alert."""
    if st.session_state.pending:
        alerts.pending_panel(where)
    elif st.session_state.alert_status == "TRIGGERED":
        alerts.show_triggered_alert()


# ---------------- 1. Home ----------------
if page == PAGES[0]:
    st.title("🛡️ AI-Based Women's Safety Alarm System")
    st.write("An educational prototype showing how simple AI/ML can flag possible emergencies "
             "(voice, motion, location risk) and provide a confirm-before-alert interface.")
    s = st.session_state.alert_status
    risk_level = st.session_state.risk_level
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Safety Status", "NORMAL" if s == "INACTIVE" else ("CHECK" if s == "PENDING" else "EMERGENCY"))
    c2.metric("Risk Level", {"LOW": "🟢 LOW", "MEDIUM": "🟡 MEDIUM", "HIGH": "🔴 HIGH"}[risk_level])
    c3.metric("Emergency Alert", "INACTIVE" if s == "INACTIVE" else s)
    c4.metric("Detected Incidents", len(st.session_state.incidents))
    st.info(f"📍 Current simulated location: **{alerts.SIM_LOCATION['name']}** "
            f"({alerts.SIM_LOCATION['lat']}, {alerts.SIM_LOCATION['lon']})")
    pending_or_done("home")
    st.subheader("Safety tips")
    st.markdown("- Share your live location with someone you trust when travelling alone.\n"
                "- Prefer well-lit, busy routes at night.\n- Keep your phone charged and emergency numbers saved.\n"
                "- Trust your instincts — this app is a demo, not a guarantee of safety.")
    if st.session_state.incidents:
        st.subheader("Incident log (this session)")
        st.table(pd.DataFrame(st.session_state.incidents))

# ---------------- 2. Voice ----------------
elif page == PAGES[1]:
    st.title("🎤 AI-Based Distress Voice Detection")
    st.caption("Audio is analysed in memory only and is never saved.")
    tab1, tab2, tab3 = st.tabs(["Upload WAV", "Microphone", "Demo sounds"])
    audio_bytes = None
    with tab1:
        up = st.file_uploader("Upload a 16-bit WAV file", type=["wav"])
        if up:
            audio_bytes = up.getvalue()
    with tab2:
        if hasattr(st, "audio_input"):
            rec = st.audio_input("Record a short clip")
            if rec:
                audio_bytes = rec.getvalue()
        else:
            st.info("Microphone input needs a newer Streamlit (pip install -U streamlit). Use upload instead.")
    with tab3:
        kind = st.radio("Pick a synthetic sound", ["distress", "calm"], horizontal=True)
        if st.button("Use this demo sound"):
            st.session_state.demo_audio = voice.make_demo_wav(kind)
        if st.session_state.get("demo_audio"):
            audio_bytes = audio_bytes or st.session_state.demo_audio
            st.audio(st.session_state.demo_audio, format="audio/wav")

    transcript = st.text_input("Transcript (type what was said — used for keyword detection offline)")
    use_stt = st.checkbox("Also try automatic speech-to-text (needs internet + SpeechRecognition)")

    if st.button("🔍 Analyze audio", type="primary"):
        if not audio_bytes:
            st.warning("Please provide audio first.")
        else:
            try:
                feats = voice.extract_features(audio_bytes)
                text = transcript or (voice.transcribe(audio_bytes) if use_stt else "")
                kw = voice.find_keyword(text)
                prob = voice.predict_distress(feats, kw)
                st.session_state.voice_result = dict(feats=feats, kw=kw, prob=prob, text=text)
                if prob >= voice.THRESHOLD and not st.session_state.pending:
                    alerts.raise_pending("Voice distress", f"distress probability {prob:.0%}", "HIGH")
                    st.session_state.risk_level = "HIGH"
            except Exception as e:
                st.error(f"Could not analyze this audio: {e}")

    r = st.session_state.get("voice_result")
    if r:
        st.subheader("Voice Analysis")
        st.metric("Distress Probability", f"{r['prob']:.0%}")
        st.progress(min(r["prob"], 1.0))
        st.write(f"**Detected Keyword:** {('“' + r['kw'] + '”') if r['kw'] else 'None'}")
        st.write(f"**Status:** {voice.status_from_probability(r['prob'])}")
        if r["text"]:
            st.caption(f"Transcript used: {r['text']}")
        st.dataframe(pd.DataFrame([r["feats"]]).round(3), hide_index=True)
    pending_or_done("voice")

# ---------------- 3. Motion ----------------
elif page == PAGES[2]:
    st.title("🏃 Fall / Abnormal Motion Detection")
    st.caption("Simulated smartphone/wearable sensor data. Rules are simple thresholds you can read in utils/motion_detection.py.")
    src = st.radio("Data source", ["Simulate a scenario", "Upload CSV"], horizontal=True)
    df = None
    if src == "Simulate a scenario":
        scenario = st.selectbox("Scenario", motion.SCENARIOS, index=3)
        df = motion.generate_motion(scenario)
    else:
        up = st.file_uploader("CSV with columns: " + ", ".join(motion.COLUMNS), type=["csv"])
        if up:
            df = pd.read_csv(up)
            missing = [c for c in motion.COLUMNS if c not in df.columns]
            if missing:
                st.error(f"Missing columns: {missing}")
                df = None
    if df is not None:
        df = motion.add_magnitude(df)
        st.plotly_chart(px.line(df, x="timestamp", y="magnitude", title="Acceleration magnitude √(x²+y²+z²)"),
                        use_container_width=True)
        label, why, abnormal = motion.classify_motion(df)
        st.subheader(f"Result: {label}")
        st.write(why)
        if abnormal:
            st.error("Possible abnormal movement detected.")
            if st.button("Start 10-second cancellation countdown", type="primary") and not st.session_state.pending:
                alerts.raise_pending("Motion: " + label, why, "HIGH", countdown=True)
                st.session_state.risk_level = "HIGH"
                st.rerun()
        else:
            st.success("Movement looks normal.")
        with st.expander("Show data table"):
            st.dataframe(df.head(100))
    pending_or_done("motion")

# ---------------- 4. Risk ----------------
elif page == PAGES[3]:
    st.title("📍 Crime Risk Prediction")
    st.warning("⚠️ SAMPLE / DEMO DATA: zones are fictional and the numbers are randomly generated. "
               "This does NOT describe real places or real crime.")
    c1, c2 = st.columns(2)
    zone = c1.selectbox("Location (demo zone)", list(risk.ZONES))
    lat, lon, area, base = risk.ZONES[zone]
    hour = c1.slider("Time of day (hour)", 0, 23, 22)
    day = c2.selectbox("Day", risk.DAYS, index=4)
    incidents = c2.slider("Historical incident count (demo)", 0, 20, base)
    reports = c2.slider("Community reports (demo)", 0, 10, 2)
    label, prob, allp = risk.predict_risk(hour, day, incidents, reports, area)
    st.session_state.risk_level = label.split()[0]
    m1, m2, m3 = st.columns(3)
    m1.metric("Predicted risk", f"{risk.ICONS[label]} {label}")
    m2.metric("Model confidence", f"{prob:.0%}")
    m3.metric("Historical incidents", incidents)
    st.info("💡 " + risk.recommendation(label))
    st.bar_chart(pd.Series(allp, name="probability"))
    st.plotly_chart(risk.make_map(zone, label), use_container_width=True)
    st.caption(f"Area type: {area}. The model only learned patterns from the demo table below.")
    with st.expander("Show sample training data"):
        st.dataframe(pd.read_csv(risk.DATA_PATH).head(50))

# ---------------- 5. Emergency ----------------
elif page == PAGES[4]:
    st.title("🚨 Emergency Alert System")
    st.text_input("Demo emergency contact (name/number — nothing is ever sent)", key="demo_contact")
    s = st.session_state.alert_status
    if s == "INACTIVE":
        st.success("🟢 Emergency system is inactive.")
    pending_or_done("emergency")
    b1, b2 = st.columns(2)
    if s == "INACTIVE" and b1.button("Simulate a manual danger signal"):
        alerts.raise_pending("Manual test", "User pressed the test button", "HIGH")
        st.rerun()
    if s == "TRIGGERED" and b2.button("Reset system"):
        alerts.cancel_alert(); st.rerun()
    if st.session_state.history:
        st.subheader("Alert history")
        for h in reversed(st.session_state.history):
            st.write("•", h)

# ---------------- 6. Vision ----------------
elif page == PAGES[5]:
    st.title("📷 Person Counter (Optional)")
    st.info("🔒 Privacy: only counts people-shaped objects. No face recognition, no identity, and "
            "images are not saved. Detection is basic and often wrong.")
    img_file = st.file_uploader("Upload an image", type=["jpg", "jpeg", "png"]) or st.camera_input("...or use webcam")
    if img_file:
        try:
            from PIL import Image
            from utils.vision import count_people
            n, out = count_people(Image.open(img_file))
            st.image(out, caption="Detections", use_container_width=True)
            st.metric("People Detected", n)
            if n == 1:
                st.warning("Single-person situation detected — remain aware.")
        except ImportError:
            st.error("Install OpenCV to use this module:  pip install opencv-python-headless")

# ---------------- 7. About ----------------
else:
    st.title("ℹ️ About Project")
    st.info(alerts.DISCLAIMER)
    st.markdown("""
**Modules**
- **Voice:** extracts loudness, duration, zero-crossing rate and brightness from audio, adds a keyword flag, and a Random Forest gives a distress probability.
- **Motion:** computes acceleration magnitude; big spike + stillness = possible fall; large swings = running; flat line = inactivity.
- **Risk:** Random Forest trained on *fictional* zone data (time, day, incident count, community reports, area type).
- **Alert:** state machine (INACTIVE → PENDING → TRIGGERED) kept in `st.session_state`. Always simulated.
- **Vision:** OpenCV HOG people counter (optional).

**Limitations:** demo data, tiny models, synthetic sound/sensor samples, no real notifications.
""")
