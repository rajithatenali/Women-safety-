"""Central emergency-alert logic. Everything is SIMULATED and lives in st.session_state.
Nothing here calls, texts or emails anyone."""
import math
import time
from datetime import datetime

import streamlit as st

SIM_LOCATION = {"name": "Demo Location (simulated)", "lat": 16.500, "lon": 80.600}
COUNTDOWN_SECONDS = 10
DISCLAIMER = ("This application is an educational AI prototype intended to demonstrate safety-assistance "
              "concepts. AI predictions may be inaccurate and should not be treated as confirmation of an "
              "emergency. In a real emergency, contact appropriate local emergency services.")


def init_state():
    defaults = {"alert_status": "INACTIVE",   # INACTIVE | PENDING | TRIGGERED
                "pending": None, "last_alert": None, "incidents": [],
                "risk_level": "LOW", "demo_contact": "", "history": []}
    for k, v in defaults.items():
        st.session_state.setdefault(k, v)


def raise_pending(detection_type, details, risk="HIGH", countdown=False):
    """A module calls this when it sees possible danger. The user must still confirm."""
    st.session_state.pending = {"type": detection_type, "details": details, "risk": risk,
                                "countdown": countdown, "deadline": time.time() + COUNTDOWN_SECONDS}
    st.session_state.alert_status = "PENDING"
    st.session_state.incidents.append({"time": datetime.now().strftime("%H:%M:%S"), "type": detection_type})


def cancel_alert():
    st.session_state.pending = None
    st.session_state.alert_status = "INACTIVE"
    st.session_state.history.append(f"{datetime.now():%H:%M:%S} - alert cancelled (user is safe)")


def trigger_alert():
    p = st.session_state.pending or {"type": "Manual", "details": "Triggered manually", "risk": "HIGH"}
    st.session_state.last_alert = {
        "location": SIM_LOCATION["name"], "coords": f'{SIM_LOCATION["lat"]}, {SIM_LOCATION["lon"]}',
        "type": p["type"], "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "risk": p["risk"], "status": "SIMULATED - not sent to anyone",
        "contact": st.session_state.demo_contact or "(none set)"}
    st.session_state.pending = None
    st.session_state.alert_status = "TRIGGERED"
    st.session_state.history.append(f"{datetime.now():%H:%M:%S} - EMERGENCY ALERT TRIGGERED ({p['type']})")


def show_triggered_alert():
    a = st.session_state.last_alert
    if not a:
        return
    st.error("🚨 EMERGENCY ALERT TRIGGERED (simulation only)")
    c1, c2 = st.columns(2)
    c1.markdown(f"**📍 Location:** {a['location']}  \n**Coordinates:** {a['coords']}  \n**Detection type:** {a['type']}")
    c2.markdown(f"**🕒 Time:** {a['time']}  \n**Risk level:** {a['risk']}  \n**Status:** {a['status']}  \n**Demo contact:** {a['contact']}")


def pending_panel(where):
    """Shows the 'please confirm' box with Cancel / Send buttons.
    If the pending alert has a countdown, the panel refreshes every second."""
    p = st.session_state.pending
    if not p:
        return

    @st.fragment(run_every=1 if p["countdown"] else None)
    def _panel():
        pend = st.session_state.pending
        if not pend:
            return
        st.warning("⚠️ Possible emergency detected. Please confirm whether you need help.")
        st.write(f"**Detected by:** {pend['type']} — {pend['details']}")
        if pend["countdown"]:
            left = max(0, math.ceil(pend["deadline"] - time.time()))
            st.progress(left / COUNTDOWN_SECONDS, text=f"⏳ Simulated alert in {left} s unless you cancel")
            if left <= 0:
                trigger_alert()
                st.rerun()
        c1, c2 = st.columns(2)
        if c1.button("✅ I'm Safe / Cancel Alert", key=f"cancel_{where}", use_container_width=True):
            cancel_alert()
            st.rerun()
        if c2.button("🚨 Send Emergency Alert", key=f"send_{where}", type="primary", use_container_width=True):
            trigger_alert()
            st.rerun()

    _panel()
