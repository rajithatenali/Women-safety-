"""Voice distress detection (beginner version).

Pipeline:  audio bytes -> simple features -> RandomForest -> distress probability.
Only the standard `wave` module + NumPy are needed for feature extraction, so
it works offline. Audio is processed in memory and never saved to disk.
"""
import io
import wave

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split

MODEL_PATH = "models/voice_model.pkl"
DATA_PATH = "data/voice_data.csv"
FEATURES = ["rms", "peak", "duration", "zcr", "centroid", "keyword_flag"]
KEYWORDS = ["please help", "save me", "emergency", "danger", "help"]  # longest first
THRESHOLD = 0.60  # probability above which we ask the user to confirm


# ---------- 1. Feature extraction ----------
def read_wav(wav_bytes):
    """Return (samples in -1..1 as float array, sample_rate). Supports 16-bit PCM WAV."""
    with wave.open(io.BytesIO(wav_bytes), "rb") as wf:
        if wf.getsampwidth() != 2:
            raise ValueError("Please use a 16-bit PCM WAV file.")
        rate, channels = wf.getframerate(), wf.getnchannels()
        raw = wf.readframes(wf.getnframes())
    data = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0
    if channels > 1:  # mix stereo down to mono
        data = data.reshape(-1, channels).mean(axis=1)
    return data, rate


def extract_features(wav_bytes):
    """Simple audio features: loudness, duration, noisiness and pitch-like 'brightness'."""
    y, sr = read_wav(wav_bytes)
    if len(y) < sr // 10:
        raise ValueError("Audio is too short (need at least 0.1 s).")
    rms = float(np.sqrt(np.mean(y ** 2)))                     # average volume
    peak = float(np.max(np.abs(y)))                            # loudest moment
    duration = len(y) / sr                                     # seconds
    zcr = float(np.mean(np.abs(np.diff(np.sign(y))) > 0))      # zero-crossing rate
    spectrum = np.abs(np.fft.rfft(y))
    freqs = np.fft.rfftfreq(len(y), 1 / sr)
    centroid = float((freqs * spectrum).sum() / (spectrum.sum() + 1e-9))  # brightness in Hz
    return {"rms": rms, "peak": peak, "duration": duration, "zcr": zcr, "centroid": centroid}


# ---------- 2. Keywords ----------
def find_keyword(text):
    """Return the first distress keyword found in the text, or None."""
    text = (text or "").lower()
    for kw in KEYWORDS:
        if kw in text:
            return kw
    return None


def transcribe(wav_bytes):
    """Optional speech-to-text using the free Google web API (needs internet).
    Returns '' if SpeechRecognition is missing or anything fails."""
    try:
        import speech_recognition as sr
        rec = sr.Recognizer()
        with sr.AudioFile(io.BytesIO(wav_bytes)) as src:
            audio = rec.record(src)
        return rec.recognize_google(audio)
    except Exception:
        return ""


# ---------- 3. Model ----------
def train_model():
    df = pd.read_csv(DATA_PATH)
    X_tr, X_te, y_tr, y_te = train_test_split(df[FEATURES], df["label"], test_size=0.2,
                                              random_state=42, stratify=df["label"])
    model = RandomForestClassifier(n_estimators=100, max_depth=6, random_state=42)
    model.fit(X_tr, y_tr)
    acc = model.score(X_te, y_te)
    joblib.dump(model, MODEL_PATH)
    return acc


def predict_distress(features, keyword):
    """Return distress probability (0..1)."""
    model = joblib.load(MODEL_PATH)
    row = pd.DataFrame([{**features, "keyword_flag": 1 if keyword else 0}])[FEATURES]
    return float(model.predict_proba(row)[0][1])


def status_from_probability(p):
    if p >= THRESHOLD:
        return "POSSIBLE DISTRESS"
    if p >= 0.35:
        return "ELEVATED - KEEP MONITORING"
    return "NORMAL"


# ---------- 4. Demo audio so you can test without a microphone ----------
def make_demo_wav(kind="distress", sr=16000, seconds=2.5):
    """Synthetic WAV: 'distress' = loud, high, noisy bursts; 'calm' = quiet low tone."""
    t = np.linspace(0, seconds, int(sr * seconds), endpoint=False)
    rng = np.random.default_rng(0)
    if kind == "distress":
        burst = (np.sin(2 * np.pi * 900 * t) * (np.sin(2 * np.pi * 3 * t) > 0)
                 + 0.4 * rng.standard_normal(len(t)))
        y = np.clip(0.6 * burst, -1, 1)
    else:
        y = 0.05 * np.sin(2 * np.pi * 180 * t)
    buf = io.BytesIO()
    with wave.open(buf, "wb") as wf:
        wf.setnchannels(1); wf.setsampwidth(2); wf.setframerate(sr)
        wf.writeframes((y * 32767).astype(np.int16).tobytes())
    return buf.getvalue()
