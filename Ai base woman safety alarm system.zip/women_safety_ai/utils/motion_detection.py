"""Fall / abnormal motion detection using simple, explainable threshold rules."""
import numpy as np
import pandas as pd

COLUMNS = ["timestamp", "accelerometer_x", "accelerometer_y", "accelerometer_z",
           "gyroscope_x", "gyroscope_y", "gyroscope_z"]
SCENARIOS = ["Normal", "Running", "Sudden Movement", "Possible Fall", "Prolonged Inactivity"]
IMPACT_G = 25.0      # m/s^2  (resting phone reads ~9.8 because of gravity)
RUN_STD = 3.5        # running makes the magnitude swing a lot
STILL_STD = 0.15     # almost no change = phone is not moving


def add_magnitude(df):
    """magnitude = sqrt(x^2 + y^2 + z^2)"""
    df = df.copy()
    df["magnitude"] = np.sqrt(df.accelerometer_x ** 2 + df.accelerometer_y ** 2 + df.accelerometer_z ** 2)
    return df


def generate_motion(scenario="Normal", seconds=30, hz=10, seed=1):
    """Create fake smartphone sensor data for a chosen scenario."""
    rng = np.random.default_rng(seed)
    t = np.arange(0, seconds, 1 / hz)
    mag = 9.8 + 1.0 * np.sin(2 * np.pi * 1.8 * t) + rng.normal(0, 0.3, len(t))   # walking
    if scenario == "Running":
        mag = 9.8 + 6.0 * np.sin(2 * np.pi * 2.8 * t) + rng.normal(0, 1.0, len(t))
    elif scenario == "Sudden Movement":
        mag[len(t) // 2] = 32                                    # one jerk, then keep moving
    elif scenario == "Possible Fall":
        i = len(t) // 3
        mag[i:i + 3] = [30, 36, 28]                              # impact
        mag[i + 3:] = 9.8 + rng.normal(0, 0.05, len(t) - i - 3)  # then lying still
    elif scenario == "Prolonged Inactivity":
        mag = 9.8 + rng.normal(0, 0.05, len(t))
    direction = np.array([0.1, 0.2, np.sqrt(1 - 0.05)])          # phone orientation
    acc = np.outer(mag, direction)
    gyro = rng.normal(0, 0.2 if scenario in ("Normal", "Running") else 0.02, (len(t), 3))
    df = pd.DataFrame(np.column_stack([t, acc, gyro]), columns=COLUMNS)
    return df


def classify_motion(df, hz=None):
    """Return (label, explanation, is_abnormal)."""
    df = add_magnitude(df)
    mag = df["magnitude"].to_numpy()
    if hz is None:
        dt = np.median(np.diff(df["timestamp"])) if len(df) > 1 else 0.1
        hz = 1 / dt if dt > 0 else 10
    duration = len(df) / hz
    hit = np.where(mag > IMPACT_G)[0]
    if len(hit):
        after = mag[hit[-1] + 1 + int(hz):]                      # 1 s after the impact
        if len(after) >= 2 * hz and after.std() < 0.5:
            return "Possible Fall", "Strong impact followed by almost no movement.", True
        return "Sudden Movement", "Sudden strong jerk, but movement continued afterwards.", True
    if mag.std() > RUN_STD:
        return "Running", "Large, repeated acceleration swings (running pattern).", False
    if mag.std() < STILL_STD and duration >= 20:
        return "Prolonged Inactivity", f"No movement for about {duration:.0f} seconds.", True
    return "Normal", "Regular walking-like movement.", False
