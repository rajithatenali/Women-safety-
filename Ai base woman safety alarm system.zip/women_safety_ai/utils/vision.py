"""Optional module: count people in an image with OpenCV's built-in HOG detector.
No faces are recognised and no identities are stored."""
import numpy as np


def count_people(pil_image):
    """Return (people_count, annotated_image_as_numpy_RGB)."""
    import cv2  # imported here so the rest of the app works without OpenCV
    img = np.array(pil_image.convert("RGB"))
    scale = 640 / img.shape[1] if img.shape[1] > 640 else 1.0
    small = cv2.resize(img, None, fx=scale, fy=scale) if scale != 1.0 else img.copy()
    hog = cv2.HOGDescriptor()
    hog.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())
    boxes, _ = hog.detectMultiScale(small, winStride=(8, 8), padding=(8, 8), scale=1.05)
    for (x, y, w, h) in boxes:
        cv2.rectangle(small, (x, y), (x + w, y + h), (255, 0, 0), 2)
    return len(boxes), small
