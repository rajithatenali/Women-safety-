"""Location risk prediction with a Random Forest, trained on SAMPLE/DEMO data only."""
import joblib
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split

MODEL_PATH = "models/risk_model.pkl"
DATA_PATH = "data/risk_data.csv"
AREA_TYPES = ["residential", "commercial", "market", "transit", "park", "isolated"]
FEATURES = ["hour", "day_num", "incident_count", "community_reports", "area_code"]
DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
LABELS = {0: "LOW RISK", 1: "MEDIUM RISK", 2: "HIGH RISK"}
ICONS = {"LOW RISK": "🟢", "MEDIUM RISK": "🟡", "HIGH RISK": "🔴"}

# Fictional demo zones (NOT real places): name -> (lat, lon, area_type, typical incidents)
ZONES = {
    "Zone A - Residential Block": (16.500, 80.600, "residential", 2),
    "Zone B - Main Market": (16.505, 80.610, "market", 8),
    "Zone C - Bus Station": (16.510, 80.598, "transit", 11),
    "Zone D - Central Park": (16.495, 80.605, "park", 5),
    "Zone E - Business District": (16.508, 80.620, "commercial", 4),
    "Zone F - Old Warehouse Lane": (16.490, 80.590, "isolated", 12),
    "Zone G - University Road": (16.515, 80.612, "commercial", 3),
    "Zone H - Riverside Path": (16.487, 80.615, "isolated", 9),
}


def train_model():
    df = pd.read_csv(DATA_PATH)
    df["area_code"] = df["area_type"].map(AREA_TYPES.index)
    df["day_num"] = df["day"].map(DAYS.index)
    X_tr, X_te, y_tr, y_te = train_test_split(df[FEATURES], df["risk_label"], test_size=0.2,
                                              random_state=42, stratify=df["risk_label"])
    model = RandomForestClassifier(n_estimators=100, max_depth=7, random_state=42)
    model.fit(X_tr, y_tr)
    joblib.dump(model, MODEL_PATH)
    return model.score(X_te, y_te)


def predict_risk(hour, day, incident_count, community_reports, area_type):
    """Return (label, probability of that label, dict of all class probabilities)."""
    model = joblib.load(MODEL_PATH)
    row = pd.DataFrame([{"hour": hour, "day_num": DAYS.index(day), "incident_count": incident_count,
                         "community_reports": community_reports,
                         "area_code": AREA_TYPES.index(area_type)}])[FEATURES]
    probs = model.predict_proba(row)[0]
    classes = list(model.classes_)
    best = int(model.predict(row)[0])
    return LABELS[best], float(probs[classes.index(best)]), {LABELS[c]: float(p) for c, p in zip(classes, probs)}


def recommendation(label):
    return {
        "LOW RISK": "Conditions look calm in the demo model. Stay aware of your surroundings as usual.",
        "MEDIUM RISK": "Prefer well-lit, busy routes, share your live location with someone you trust, and keep your phone charged.",
        "HIGH RISK": "Consider another route or travelling with someone, tell a trusted contact, and keep emergency numbers ready.",
    }[label]


def make_map(selected_zone=None, label="LOW RISK"):
    """Plotly map of the fictional demo zones (uses free OpenStreetMap tiles)."""
    import plotly.express as px  # imported here so training works without plotly
    rows = [{"zone": n, "lat": v[0], "lon": v[1], "typical_incidents": v[3],
             "selected": "Selected" if n == selected_zone else "Other zones"} for n, v in ZONES.items()]
    df = pd.DataFrame(rows)
    fn = getattr(px, "scatter_map", None) or px.scatter_mapbox
    kwargs = {"map_style": "open-street-map"} if hasattr(px, "scatter_map") else {"mapbox_style": "open-street-map"}
    fig = fn(df, lat="lat", lon="lon", hover_name="zone", size="typical_incidents", color="selected",
             color_discrete_map={"Selected": "red", "Other zones": "royalblue"},
             zoom=12, height=420, **kwargs)
    fig.update_layout(margin=dict(l=0, r=0, t=0, b=0))
    return fig
