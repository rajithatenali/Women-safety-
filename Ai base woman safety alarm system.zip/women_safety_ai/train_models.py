"""Creates the SAMPLE datasets and trains both ML models.
Run:  python train_models.py     (app.py also runs it automatically if files are missing)"""
import os

import numpy as np
import pandas as pd

from utils import motion_detection, risk_prediction, voice_detection


def make_voice_data(n=600, seed=42):
    rng = np.random.default_rng(seed)
    rows = []
    for _ in range(n):
        distress = rng.random() < 0.5
        if distress:   # loud, bright, noisy, often contains a keyword
            r = dict(rms=rng.uniform(0.12, 0.5), peak=rng.uniform(0.5, 1.0), duration=rng.uniform(0.5, 6),
                     zcr=rng.uniform(0.10, 0.35), centroid=rng.uniform(1200, 3500),
                     keyword_flag=int(rng.random() < 0.7))
        else:          # quieter, lower, calmer, rarely a keyword
            r = dict(rms=rng.uniform(0.01, 0.15), peak=rng.uniform(0.05, 0.6), duration=rng.uniform(0.5, 8),
                     zcr=rng.uniform(0.02, 0.15), centroid=rng.uniform(300, 1800),
                     keyword_flag=int(rng.random() < 0.03))
        r["label"] = int(distress) if rng.random() > 0.05 else int(not distress)  # 5% label noise
        rows.append(r)
    return pd.DataFrame(rows).round(4)


def make_risk_data(n=800, seed=7):
    rng = np.random.default_rng(seed)
    area_weight = {"residential": 0, "commercial": 0.5, "market": 1, "park": 1.5, "transit": 1.5, "isolated": 2.5}
    rows = []
    for _ in range(n):
        zone, (lat, lon, area, base) = list(risk_prediction.ZONES.items())[rng.integers(0, 8)]
        hour, day = int(rng.integers(0, 24)), risk_prediction.DAYS[rng.integers(0, 7)]
        incidents = int(np.clip(base + rng.integers(-2, 4), 0, 20))
        reports = int(rng.integers(0, 11))
        night = 3 if (hour >= 21 or hour < 5) else 0
        score = 0.5 * incidents + night + 0.6 * reports + area_weight[area] + rng.normal(0, 0.8)
        label = 0 if score < 6 else (1 if score < 11 else 2)
        rows.append(dict(latitude=lat, longitude=lon, hour=hour, day=day, incident_count=incidents,
                         community_reports=reports, area_type=area, risk_label=label))
    return pd.DataFrame(rows)


def main():
    for folder in ("data", "models"):
        os.makedirs(folder, exist_ok=True)
    make_voice_data().to_csv(voice_detection.DATA_PATH, index=False)
    make_risk_data().to_csv(risk_prediction.DATA_PATH, index=False)
    motion_detection.generate_motion("Possible Fall").to_csv("data/motion_data.csv", index=False)
    print("Voice model accuracy:", round(voice_detection.train_model(), 3))
    print("Risk model accuracy :", round(risk_prediction.train_model(), 3))


if __name__ == "__main__":
    main()
